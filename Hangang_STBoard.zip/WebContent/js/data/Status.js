/**
 * @FileName  : Status.js
 * @Project     : hangang
 * @Date         : 2014. 3. 24. 
 * @작성자      : leeyunsoo
 * @변경이력 :
 * @프로그램 설명 : 맵의 모든 정보를 가지고 잇는 클래스
 */
function Status(){
	
}