package util;

import java.util.Hashtable;

public interface IChart {
	public void drawChart(Hashtable<String, String> dataSet);
}
