package Data;
import java.sql.*;

public interface IConnection {
	public Connection getConnection();
}
